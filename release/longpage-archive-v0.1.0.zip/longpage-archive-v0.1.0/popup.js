"use strict";
(() => {
  // src/ui/popup.ts
  var titleElement = document.querySelector("#page-title");
  var statusPanel = document.querySelector("#status-panel");
  var statusText = document.querySelector("#status-text");
  var statusPercent = document.querySelector("#status-percent");
  var progressBar = document.querySelector("#progress-bar");
  var cancelButton = document.querySelector("#cancel-button");
  var notice = document.querySelector("#notice");
  var actionButtons = [...document.querySelectorAll("[data-format]")];
  function isSupportedUrl(url) {
    return /^https?:\/\//i.test(url) && !/^https:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)/i.test(url);
  }
  function setNotice(message, kind = "normal") {
    notice.textContent = message;
    notice.className = `notice${kind === "normal" ? "" : ` notice--${kind}`}`;
  }
  function renderState(state) {
    actionButtons.forEach((button) => {
      button.disabled = state.active;
    });
    statusPanel.hidden = !state.active && !state.message;
    statusText.textContent = state.message || "\u7B49\u5F85\u4EFB\u52A1";
    const percent = state.total > 0 ? Math.round(state.completed / state.total * 100) : 0;
    statusPercent.textContent = state.total > 0 ? `${percent}%` : "";
    progressBar.style.width = `${percent}%`;
    cancelButton.hidden = !state.active;
    if (!state.active && state.message) {
      setNotice(state.message, state.message.startsWith("\u5BFC\u51FA\u5931\u8D25") ? "error" : "success");
    }
  }
  async function requestOfflinePermission() {
    return chrome.permissions.request({ origins: ["http://*/*", "https://*/*"] });
  }
  async function startExport(format) {
    if (format === "markdown-zip") {
      const granted = await requestOfflinePermission();
      if (!granted) {
        setNotice("\u672A\u83B7\u5F97\u56FE\u7247\u8BBF\u95EE\u6743\u9650\uFF0C\u53EF\u6539\u7528\u201C\u5FEB\u901F Markdown\u201D\u3002", "error");
        return;
      }
    }
    const response = await chrome.runtime.sendMessage({ type: "START_EXPORT", format });
    if (!response?.ok) {
      setNotice(response?.error || "\u65E0\u6CD5\u542F\u52A8\u5BFC\u51FA\u4EFB\u52A1", "error");
    }
  }
  for (const button of actionButtons) {
    button.addEventListener("click", () => {
      const format = button.dataset.format;
      void startExport(format).catch((error) => {
        setNotice(error instanceof Error ? error.message : String(error), "error");
      });
    });
  }
  cancelButton.addEventListener("click", () => {
    void chrome.runtime.sendMessage({ type: "CANCEL_EXPORT" });
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "EXPORT_STATUS") {
      renderState(message.state);
    }
    return false;
  });
  void (async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    titleElement.textContent = tab?.title || "\u672A\u547D\u540D\u7F51\u9875";
    if (!tab?.url || !isSupportedUrl(tab.url)) {
      actionButtons.forEach((button) => {
        button.disabled = true;
      });
      setNotice("\u5F53\u524D\u9875\u9762\u53D7 Chrome \u9650\u5236\uFF0C\u65E0\u6CD5\u5BFC\u51FA\u3002", "error");
      return;
    }
    const response = await chrome.runtime.sendMessage({ type: "GET_EXPORT_STATE" });
    if (response?.result) renderState(response.result);
  })().catch((error) => {
    setNotice(error instanceof Error ? error.message : String(error), "error");
  });
})();
//# sourceMappingURL=popup.js.map
