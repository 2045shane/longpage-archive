"use strict";
(() => {
  // src/capture/plan.ts
  function createCaptureFrames(pageHeight, viewportHeight) {
    if (!Number.isFinite(pageHeight) || pageHeight <= 0) {
      throw new Error("\u9875\u9762\u9AD8\u5EA6\u5FC5\u987B\u5927\u4E8E 0");
    }
    if (!Number.isFinite(viewportHeight) || viewportHeight <= 0) {
      throw new Error("\u89C6\u53E3\u9AD8\u5EA6\u5FC5\u987B\u5927\u4E8E 0");
    }
    const safePageHeight = Math.ceil(pageHeight);
    const safeViewportHeight = Math.ceil(viewportHeight);
    const maxScrollY = Math.max(0, safePageHeight - safeViewportHeight);
    const positions = [];
    for (let scrollY = 0; scrollY < maxScrollY; scrollY += safeViewportHeight) {
      positions.push(scrollY);
    }
    if (positions.at(-1) !== maxScrollY) {
      positions.push(maxScrollY);
    }
    let capturedBottom = 0;
    return positions.map((scrollY) => {
      const cropTop = Math.max(0, capturedBottom - scrollY);
      const captureHeight = Math.min(
        safeViewportHeight - cropTop,
        safePageHeight - scrollY - cropTop
      );
      capturedBottom = scrollY + cropTop + captureHeight;
      return { scrollY, cropTop, captureHeight };
    });
  }

  // src/shared/filename.ts
  var RESERVED_FILENAME_CHARACTERS = /[<>:"/\\|?*\u0000-\u001f]/g;
  function sanitizeFilename(value, fallback = "\u672A\u547D\u540D\u7F51\u9875") {
    const sanitized = value.normalize("NFC").replace(RESERVED_FILENAME_CHARACTERS, "-").replace(/\s+/g, " ").trim().replace(/[. ]+$/g, "").slice(0, 120).trim();
    return sanitized || fallback;
  }

  // src/runtime/export-session.ts
  var EMPTY_STATE = {
    active: false,
    cancelled: false,
    completed: 0,
    total: 0,
    message: "",
    format: null
  };
  var ExportSession = class {
    state = { ...EMPTY_STATE };
    begin(format, total = 0) {
      if (this.state.active) {
        throw new Error("\u5DF2\u6709\u5BFC\u51FA\u4EFB\u52A1\u6B63\u5728\u6267\u884C");
      }
      this.state = {
        active: true,
        cancelled: false,
        completed: 0,
        total,
        message: "\u6B63\u5728\u51C6\u5907\u2026",
        format
      };
    }
    update(completed, message, total = this.state.total) {
      if (!this.state.active) {
        return;
      }
      this.state = { ...this.state, completed, total, message };
    }
    cancel() {
      if (this.state.active) {
        this.state = { ...this.state, cancelled: true, message: "\u6B63\u5728\u53D6\u6D88\u2026" };
      }
    }
    isCancelled() {
      return this.state.cancelled;
    }
    snapshot() {
      return { ...this.state };
    }
    finish() {
      this.state = { ...EMPTY_STATE };
    }
  };

  // src/runtime/background.ts
  var ExportCancelledError = class extends Error {
    constructor() {
      super("\u4EFB\u52A1\u5DF2\u53D6\u6D88");
    }
  };
  var session = new ExportSession();
  function broadcastState(state = session.snapshot()) {
    void chrome.runtime.sendMessage({ type: "EXPORT_STATUS", state }).catch(() => void 0);
  }
  function updateState(completed, message, total) {
    session.update(completed, message, total);
    broadcastState();
  }
  async function sendTab(tabId, message) {
    const response = await chrome.tabs.sendMessage(tabId, message);
    if (!response?.ok) throw new Error(response?.error || "\u9875\u9762\u811A\u672C\u6CA1\u6709\u54CD\u5E94");
    return response.result;
  }
  async function sendOffscreen(message) {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw new Error(response?.error || "\u79BB\u5C4F\u5904\u7406\u5668\u6CA1\u6709\u54CD\u5E94");
    return response.result;
  }
  async function ensureContentScript(tabId) {
    try {
      await sendTab(tabId, { type: "PING" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
      await sendTab(tabId, { type: "PING" });
    }
  }
  async function ensureOffscreenDocument() {
    if (await chrome.offscreen.hasDocument()) return;
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: [chrome.offscreen.Reason.BLOBS],
      justification: "\u62FC\u63A5\u7F51\u9875\u622A\u56FE\u5E76\u751F\u6210\u672C\u5730 PNG\u3001PDF \u548C ZIP \u6587\u4EF6"
    });
  }
  function assertSupportedTab(tab) {
    const url = tab.url ?? "";
    const isWebPage = /^https?:\/\//i.test(url);
    const isChromeStore = /^https:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)/i.test(url);
    if (!tab.id || !isWebPage || isChromeStore) {
      throw new Error("\u5F53\u524D\u9875\u9762\u53D7 Chrome \u9650\u5236\uFF0C\u65E0\u6CD5\u622A\u56FE\u6216\u63D0\u53D6\u6B63\u6587");
    }
  }
  function checkCancelled() {
    if (session.isCancelled()) throw new ExportCancelledError();
  }
  async function handleCapture(tab, format) {
    let contentReady = false;
    try {
      await ensureContentScript(tab.id);
      contentReady = true;
      updateState(0, "\u6B63\u5728\u9884\u52A0\u8F7D\u9875\u9762\u2026");
      const metrics = await sendTab(tab.id, { type: "PREPARE_CAPTURE" });
      checkCancelled();
      const frames = createCaptureFrames(metrics.pageHeight, metrics.viewportHeight);
      updateState(0, `\u51C6\u5907\u6355\u83B7 ${frames.length} \u5C4F`, frames.length);
      const capturedFrames = [];
      for (let index = 0; index < frames.length; index += 1) {
        checkCancelled();
        const frame = frames[index];
        await sendTab(tab.id, { type: "SCROLL_CAPTURE", index, scrollY: frame.scrollY });
        checkCancelled();
        const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
        capturedFrames.push({ ...frame, dataUrl });
        const completed = index + 1;
        const message = `\u6B63\u5728\u6355\u83B7\u7B2C ${completed}/${frames.length} \u5C4F`;
        updateState(completed, message, frames.length);
        await sendTab(tab.id, {
          type: "SHOW_CAPTURE_PROGRESS",
          completed,
          total: frames.length,
          message
        });
      }
      checkCancelled();
      updateState(frames.length, format === "pdf" ? "\u6B63\u5728\u751F\u6210 PDF\u2026" : "\u6B63\u5728\u62FC\u63A5\u957F\u56FE\u2026");
      await ensureOffscreenDocument();
      const rendered = await sendOffscreen({
        type: "RENDER_CAPTURE",
        format,
        frames: capturedFrames,
        pageHeight: metrics.pageHeight,
        viewportHeight: metrics.viewportHeight,
        viewportWidth: metrics.viewportWidth
      });
      checkCancelled();
      await chrome.downloads.download({
        url: rendered.url,
        filename: `${sanitizeFilename(metrics.title)}.${format}`,
        saveAs: true
      });
    } finally {
      if (contentReady) {
        await sendTab(tab.id, { type: "RESTORE_CAPTURE" }).catch(() => void 0);
      }
    }
  }
  async function handleMarkdown(tab, format) {
    await ensureContentScript(tab.id);
    updateState(0, "\u6B63\u5728\u8BC6\u522B\u7F51\u9875\u6B63\u6587\u2026");
    const payload = await sendTab(tab.id, { type: "EXTRACT_MARKDOWN" });
    checkCancelled();
    await ensureOffscreenDocument();
    const safeTitle = sanitizeFilename(payload.title);
    if (format === "markdown") {
      const result2 = await sendOffscreen({
        type: "CREATE_TEXT_DOWNLOAD",
        text: payload.quickMarkdown,
        mimeType: "text/markdown;charset=utf-8"
      });
      checkCancelled();
      await chrome.downloads.download({ url: result2.url, filename: `${safeTitle}.md`, saveAs: true });
      return;
    }
    updateState(0, `\u6B63\u5728\u4FDD\u5B58 ${payload.assets.length} \u5F20\u6B63\u6587\u56FE\u7247\u2026`);
    const result = await sendOffscreen({
      type: "BUILD_MARKDOWN_ZIP",
      markdown: payload.offlineMarkdown,
      markdownFilename: `${safeTitle}.md`,
      assets: payload.assets
    });
    checkCancelled();
    await chrome.downloads.download({ url: result.url, filename: `${safeTitle}-Markdown.zip`, saveAs: true });
  }
  async function runExport(format) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) throw new Error("\u6CA1\u6709\u627E\u5230\u5F53\u524D\u7F51\u9875");
      assertSupportedTab(tab);
      if (format === "png" || format === "pdf") {
        await handleCapture(tab, format);
      } else {
        await handleMarkdown(tab, format);
      }
      const finalState = {
        ...session.snapshot(),
        active: false,
        completed: session.snapshot().total,
        message: "\u5BFC\u51FA\u6587\u4EF6\u5DF2\u4EA4\u7ED9 Chrome \u4E0B\u8F7D"
      };
      broadcastState(finalState);
    } catch (error) {
      const message = error instanceof ExportCancelledError || error instanceof Error && error.message === "EXPORT_CANCELLED" ? "\u4EFB\u52A1\u5DF2\u53D6\u6D88\uFF0C\u9875\u9762\u5DF2\u6062\u590D" : `\u5BFC\u51FA\u5931\u8D25\uFF1A${error instanceof Error ? error.message : String(error)}`;
      broadcastState({ ...session.snapshot(), active: false, message });
    } finally {
      session.finish();
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    switch (message.type) {
      case "START_EXPORT": {
        try {
          const format = message.format;
          if (!["png", "pdf", "markdown", "markdown-zip"].includes(format)) {
            throw new Error("\u672A\u77E5\u5BFC\u51FA\u683C\u5F0F");
          }
          session.begin(format);
          broadcastState();
          void runExport(format);
          sendResponse({ ok: true });
        } catch (error) {
          sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) });
        }
        return false;
      }
      case "CANCEL_EXPORT":
        session.cancel();
        broadcastState();
        sendResponse({ ok: true });
        return false;
      case "GET_EXPORT_STATE":
        sendResponse({ ok: true, result: session.snapshot() });
        return false;
      default:
        return false;
    }
  });
})();
//# sourceMappingURL=background.js.map
